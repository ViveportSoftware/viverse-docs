var class_unity_properties_1_1_unity_engine_1_1_camera =
[
    [ "backgroundColor", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a4d6c1e8b92f498345aad7a776a9ef258", null ],
    [ "cullingMask", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a4179ec6927fff21fe53aa66a4f392f3c", null ],
    [ "enabled", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a3437124321cea76d38e3c3cddcf36a3b", null ],
    [ "farClipPlane", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a8b831f573146e28cf7880ffbde99bcd4", null ],
    [ "fieldOfView", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a28c8332697a4d0ce304a1798381d4b73", null ],
    [ "nearClipPlane", "class_unity_properties_1_1_unity_engine_1_1_camera.html#abde60e2536e16822fcb055980cf25dbb", null ],
    [ "orthographic", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a0c6b0a1b77b86359ecf8e79209687397", null ],
    [ "orthographicSize", "class_unity_properties_1_1_unity_engine_1_1_camera.html#acca92828785d5372c7f63ce002e49276", null ],
    [ "rect", "class_unity_properties_1_1_unity_engine_1_1_camera.html#a920f189a9709042797755618ce9bb1c0", null ]
];