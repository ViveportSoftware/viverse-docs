var class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_condition =
[
    [ "mode", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_condition.html#a57ee0fc104193efc918de49e8b561d88", null ],
    [ "parameter", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_condition.html#aa8f38d5f36dec28a09f934f0263f02fb", null ],
    [ "threshold", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_condition.html#a16d3407e68b24ff99f7b58731f69e980", null ]
];