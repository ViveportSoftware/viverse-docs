var class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group =
[
    [ "childAlignment", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#ad94dada8d35ac60dd02873efecb61105", null ],
    [ "childControlHeight", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#aee784f5079e33fbf17c2ca8641fc56a6", null ],
    [ "childControlWidth", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#a65c1ef892cd616f2779b3788eb8db890", null ],
    [ "enable", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#a8c60d550a1a399a37e91f60bdd122757", null ],
    [ "padding", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#aec8543fdfbc84c9a55b0b5cb8f409c2e", null ],
    [ "reverseArrangement", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#ac5e8c8606473fe2883dc5bdd031530d3", null ],
    [ "spacing", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_horizontal_layout_group.html#a142ee3ebeceefd4056d6543014428146", null ]
];