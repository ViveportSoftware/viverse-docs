var class_playcanvas_1_1_properties_1_1_render =
[
    [ "asset", "class_playcanvas_1_1_properties_1_1_render.html#a959b6728202e4b830984dad7b28e0af7", null ],
    [ "castShadows", "class_playcanvas_1_1_properties_1_1_render.html#ac0d91fadecca1a9172f9ebbcaa68edc5", null ],
    [ "layers", "class_playcanvas_1_1_properties_1_1_render.html#aac9b3c97b9b140b4234106985b49cfec", null ],
    [ "materialAssets", "class_playcanvas_1_1_properties_1_1_render.html#ab276cddad5c6164398177f7ac4eed1ce", null ],
    [ "receiveShadows", "class_playcanvas_1_1_properties_1_1_render.html#a93edbd0d49221587e6862ff05b15fb60", null ],
    [ "rootBone", "class_playcanvas_1_1_properties_1_1_render.html#a720c26e758b0f3a94748d067ccadeed6", null ],
    [ "type", "class_playcanvas_1_1_properties_1_1_render.html#ae5ec1a4ac5da1e3d4dcef52d0731559e", null ]
];