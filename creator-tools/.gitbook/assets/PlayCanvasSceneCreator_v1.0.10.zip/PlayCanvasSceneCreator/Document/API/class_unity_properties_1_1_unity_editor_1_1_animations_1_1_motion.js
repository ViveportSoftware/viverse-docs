var class_unity_properties_1_1_unity_editor_1_1_animations_1_1_motion =
[
    [ "isLooping", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_motion.html#abaf7b8b5b33408b596e19f3c7c737804", null ]
];