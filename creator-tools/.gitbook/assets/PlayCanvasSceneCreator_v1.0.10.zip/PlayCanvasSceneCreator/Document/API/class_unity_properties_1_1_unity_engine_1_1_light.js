var class_unity_properties_1_1_unity_engine_1_1_light =
[
    [ "color", "class_unity_properties_1_1_unity_engine_1_1_light.html#aa75a3eda73dae448cbdf9d02c02053d4", null ],
    [ "cookie", "class_unity_properties_1_1_unity_engine_1_1_light.html#af846d68cf62580db30beafc3741672c2", null ],
    [ "cullingMask", "class_unity_properties_1_1_unity_engine_1_1_light.html#a1ceccedd70a71cd8d305ec51c99b1b1d", null ],
    [ "innerSpotAngle", "class_unity_properties_1_1_unity_engine_1_1_light.html#a0dca9715765201035b88b2998f531a42", null ],
    [ "intensity", "class_unity_properties_1_1_unity_engine_1_1_light.html#a1d4acbb8c8bdeea2202d5164bf0c31af", null ],
    [ "isStatic", "class_unity_properties_1_1_unity_engine_1_1_light.html#af6cf478d3b19c24e982bd669115526ac", null ],
    [ "lightmapBakeType", "class_unity_properties_1_1_unity_engine_1_1_light.html#a1ed83b2b01ff2047092399c14b0f93fc", null ],
    [ "range", "class_unity_properties_1_1_unity_engine_1_1_light.html#a60d8f6b55c3a1acecaa624ba4094a7c3", null ],
    [ "shadowResolution", "class_unity_properties_1_1_unity_engine_1_1_light.html#a9bd2d40bc724645bcfd169a906853fa5", null ],
    [ "shadows", "class_unity_properties_1_1_unity_engine_1_1_light.html#a301b1ca69a3d53333ebea3d748c286df", null ],
    [ "spotAngle", "class_unity_properties_1_1_unity_engine_1_1_light.html#a102f81ede99f63f0ef783473954c704f", null ],
    [ "type", "class_unity_properties_1_1_unity_engine_1_1_light.html#ad75609ab0906f276cec889dc1f6e296a", null ]
];