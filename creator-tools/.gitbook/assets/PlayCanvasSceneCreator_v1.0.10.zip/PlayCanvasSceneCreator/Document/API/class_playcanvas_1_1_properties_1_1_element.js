var class_playcanvas_1_1_properties_1_1_element =
[
    [ "Fitmode", "class_playcanvas_1_1_properties_1_1_element.html#ad8d67aedfd1ca267f26f97d97c150cb9", [
      [ "stretch", "class_playcanvas_1_1_properties_1_1_element.html#ad8d67aedfd1ca267f26f97d97c150cb9a7e84944493e379c33782eb1c9ecb82c3", null ],
      [ "contain", "class_playcanvas_1_1_properties_1_1_element.html#ad8d67aedfd1ca267f26f97d97c150cb9ac58ff5e3a379801b6cc137158d5545fe", null ],
      [ "cover", "class_playcanvas_1_1_properties_1_1_element.html#ad8d67aedfd1ca267f26f97d97c150cb9a41d0e299ca1abeb2094852da042165c7", null ]
    ] ],
    [ "alignment", "class_playcanvas_1_1_properties_1_1_element.html#a14cbdf1722044d9d9f92d2ed77282726", null ],
    [ "anchor", "class_playcanvas_1_1_properties_1_1_element.html#a1174f9c531178472148f7ddb454ea7e5", null ],
    [ "color", "class_playcanvas_1_1_properties_1_1_element.html#aefa912543705346b7f8d3e86cbd23936", null ],
    [ "fitMode", "class_playcanvas_1_1_properties_1_1_element.html#a3a6cc768b190f2b7ca7bb7866ac4fca3", null ],
    [ "fontAsset", "class_playcanvas_1_1_properties_1_1_element.html#a8baee1ab3b0a48c0c45c27bc1548d4e0", null ],
    [ "fontSize", "class_playcanvas_1_1_properties_1_1_element.html#a53e924006bdfc23dea975db81f93b4de", null ],
    [ "height", "class_playcanvas_1_1_properties_1_1_element.html#a512f8fc8eb0f6812355ead0b6a8a7173", null ],
    [ "layers", "class_playcanvas_1_1_properties_1_1_element.html#a7d7c3eaae4ad486bcdbd69d1aac70b76", null ],
    [ "margin", "class_playcanvas_1_1_properties_1_1_element.html#aee1b836723c0ca00b25ed3fe35701ba1", null ],
    [ "mask", "class_playcanvas_1_1_properties_1_1_element.html#a7d0a13c70544c3869c7d52e7d06a5ad2", null ],
    [ "maxFontSize", "class_playcanvas_1_1_properties_1_1_element.html#a848a49e269e725d1b587ede7c4312151", null ],
    [ "minFontSize", "class_playcanvas_1_1_properties_1_1_element.html#ae7ecb1e43ff7c01972e0e5af7463fe84", null ],
    [ "opacity", "class_playcanvas_1_1_properties_1_1_element.html#a7b7f61b7559c195eeaa1a0694fa809b6", null ],
    [ "pivot", "class_playcanvas_1_1_properties_1_1_element.html#a5d93e3e31bdb6062f64f531459254eb4", null ],
    [ "text", "class_playcanvas_1_1_properties_1_1_element.html#a88d2beae5a771d9b2118081c524ae12a", null ],
    [ "textureAsset", "class_playcanvas_1_1_properties_1_1_element.html#abf6cffc1352df60a351e6677c1114e23", null ],
    [ "type", "class_playcanvas_1_1_properties_1_1_element.html#a09a24ef8dee7f1f281728e8ca264610c", null ],
    [ "useInput", "class_playcanvas_1_1_properties_1_1_element.html#a0b387792487970dbf22cfc79ff73d370", null ],
    [ "width", "class_playcanvas_1_1_properties_1_1_element.html#a9a87907b1bca2c306e44a16dbb31e04e", null ],
    [ "wrapLines", "class_playcanvas_1_1_properties_1_1_element.html#ae6f124782ac7a43f70613d968d8c64cb", null ]
];