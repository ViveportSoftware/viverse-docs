var class_unity_properties_1_1_unity_engine_1_1_mesh_collider =
[
    [ "center", "class_unity_properties_1_1_unity_engine_1_1_mesh_collider.html#aefc77438d2e4af551d69508511ca1a2e", null ],
    [ "enabled", "class_unity_properties_1_1_unity_engine_1_1_mesh_collider.html#aa7ffdb53180c6b4a5090260cad4d11b9", null ],
    [ "sharedMesh", "class_unity_properties_1_1_unity_engine_1_1_mesh_collider.html#a6dbbccaac8110b93c6b6480da0f2fc7e", null ]
];