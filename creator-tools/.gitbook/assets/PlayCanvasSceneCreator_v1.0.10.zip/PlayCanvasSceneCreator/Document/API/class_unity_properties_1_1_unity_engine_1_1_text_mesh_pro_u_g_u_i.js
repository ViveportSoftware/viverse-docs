var class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i =
[
    [ "color", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#ade18546f99cb632e1ad013e66fbef4bc", null ],
    [ "enableWordWrapping", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#a484ace2692eeb1b8416aed506c9fbe61", null ],
    [ "fontSize", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#aee8591b2cf79a097b67f0bb089f18386", null ],
    [ "fontSizeMax", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#a06d06ec320eba11aadde30a64f97199c", null ],
    [ "fontSizeMin", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#a5fd51219d1b3e8a5a4c9f54b76723a0e", null ],
    [ "horizontalAlignment", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#aad5a6a310f2216a5357dccdc7828ab79", null ],
    [ "m_fontAsset", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#ac5349a59a32473e7d0160c6bd0a8d306", null ],
    [ "text", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#a0669b46b7bb7299f4719c2cfbb3b2500", null ],
    [ "verticalAlignment", "class_unity_properties_1_1_unity_engine_1_1_text_mesh_pro_u_g_u_i.html#adfb608f1e939d77db27fb332f3ca7995", null ]
];