var class_unity_properties_1_1_material =
[
    [ "_BumpMap", "class_unity_properties_1_1_material.html#a83aa27c55ce5a9e0aeca322570e5191c", null ],
    [ "_EmissionColor", "class_unity_properties_1_1_material.html#a40a46a6b2b2954fb6ec7a3355caa1350", null ],
    [ "_EmissionMap", "class_unity_properties_1_1_material.html#ab2125fbb5bfb5c348a918089c5e9b335", null ],
    [ "_MetallicGlossMap", "class_unity_properties_1_1_material.html#a106057c2a85fa77f38d367b21cce47c4", null ],
    [ "_OcclusionMap", "class_unity_properties_1_1_material.html#a90c7d822751d3b196770dfe83ea8c1fb", null ],
    [ "_OcclusionStrength", "class_unity_properties_1_1_material.html#adac01ce9f591bc109113ebf3148d7493", null ],
    [ "_ParallaxMap", "class_unity_properties_1_1_material.html#afeefaaf94d096253ea8e9201ecccd796", null ]
];