var class_playcanvas_1_1_properties_1_1_camera =
[
    [ "clearColor", "class_playcanvas_1_1_properties_1_1_camera.html#a15fbb48d906f43808635e4d87326a871", null ],
    [ "enabled", "class_playcanvas_1_1_properties_1_1_camera.html#a67a6c62393650e4133cffa3d7590a8e0", null ],
    [ "farClip", "class_playcanvas_1_1_properties_1_1_camera.html#ad906d7b5f25815bdb1ae1fb2072270e3", null ],
    [ "fov", "class_playcanvas_1_1_properties_1_1_camera.html#a01f3caacb7dc1064a602bdda31d7fb4e", null ],
    [ "layers", "class_playcanvas_1_1_properties_1_1_camera.html#ad9824c16df3c1db3a73b8bda5cac3234", null ],
    [ "nearClip", "class_playcanvas_1_1_properties_1_1_camera.html#a239c3d86067b3385f5253d0afa76fe05", null ],
    [ "orthoHeight", "class_playcanvas_1_1_properties_1_1_camera.html#a3fd5094de8088ae44ec019cebaf8e731", null ],
    [ "projection", "class_playcanvas_1_1_properties_1_1_camera.html#afbd08025057d84be56e26fe80a400c9a", null ],
    [ "rect", "class_playcanvas_1_1_properties_1_1_camera.html#ad29fd6793977cf634c6bdb8c94408af4", null ]
];