var class_unity_properties_1_1_unity_engine_1_1_skinned_mesh_renderer =
[
    [ "receiveShadows", "class_unity_properties_1_1_unity_engine_1_1_skinned_mesh_renderer.html#a42212946799aad1a2d0bf3d860e55774", null ],
    [ "rootBone", "class_unity_properties_1_1_unity_engine_1_1_skinned_mesh_renderer.html#a597d0c5a6e3518ab53feef9d4634d9b7", null ],
    [ "shadowCastingMode", "class_unity_properties_1_1_unity_engine_1_1_skinned_mesh_renderer.html#afff26ae77ec903caad5ec23b49cebb9b", null ],
    [ "sharedMaterials", "class_unity_properties_1_1_unity_engine_1_1_skinned_mesh_renderer.html#a40f0e925ef154afd1e9bfb06cc526876", null ],
    [ "sharedMesh", "class_unity_properties_1_1_unity_engine_1_1_skinned_mesh_renderer.html#a28f264fc838be55301a6e9f180ef44dd", null ]
];