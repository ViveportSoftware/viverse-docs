var class_playcanvas_1_1_properties_1_1_sprite =
[
    [ "Clip", "class_playcanvas_1_1_properties_1_1_sprite_1_1_clip.html", null ],
    [ "clips", "class_playcanvas_1_1_properties_1_1_sprite.html#a905444381ab69257cec4b378c6061747", null ],
    [ "color", "class_playcanvas_1_1_properties_1_1_sprite.html#aa2f395510ebbce0a63d4647b7d796942", null ],
    [ "flipX", "class_playcanvas_1_1_properties_1_1_sprite.html#a66bd87755d7714ec1d035a2d2467d694", null ],
    [ "flipY", "class_playcanvas_1_1_properties_1_1_sprite.html#a1d3c76f5f593a6a93ea5f5ac09ec6ea3", null ],
    [ "layers", "class_playcanvas_1_1_properties_1_1_sprite.html#a74e0d11e74f61afb54fbc3c4702e4d0c", null ],
    [ "opacity", "class_playcanvas_1_1_properties_1_1_sprite.html#a7ce38d2caf632740ac5ce9bdd86d25c6", null ],
    [ "type", "class_playcanvas_1_1_properties_1_1_sprite.html#a2cf69239ec7555b905b492b9adc78faf", null ]
];