var class_unity_properties_1_1_unity_engine_1_1_box_collider =
[
    [ "center", "class_unity_properties_1_1_unity_engine_1_1_box_collider.html#a536f2ce8ef8de9d8c6add77516e4408d", null ],
    [ "enabled", "class_unity_properties_1_1_unity_engine_1_1_box_collider.html#a060e0ec5c5b58d7a7e9ee1a7a24adca9", null ],
    [ "size", "class_unity_properties_1_1_unity_engine_1_1_box_collider.html#a61b7730d94649bbdeca3e2ac6e98b5c8", null ]
];