var class_unity_properties_1_1_unity_engine_1_1_transform =
[
    [ "name", "class_unity_properties_1_1_unity_engine_1_1_transform.html#ad38345ec4fcd677ea1789df98f2c98bb", null ],
    [ "parent", "class_unity_properties_1_1_unity_engine_1_1_transform.html#ace7c53e04f4cdf684a73481fb314387c", null ],
    [ "tag", "class_unity_properties_1_1_unity_engine_1_1_transform.html#a8f765b88d9023aa5c6c51518fb98cbcd", null ]
];