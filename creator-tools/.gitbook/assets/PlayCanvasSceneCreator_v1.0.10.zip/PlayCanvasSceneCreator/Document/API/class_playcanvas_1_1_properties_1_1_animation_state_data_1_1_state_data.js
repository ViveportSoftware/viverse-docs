var class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data =
[
    [ "defaultState", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#a8b67b14eaf55c66217782e82df6ccd0c", null ],
    [ "id", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#aadd1d98323be7b11a4b285e0e2d8b76d", null ],
    [ "loop", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#a8689c9bb586f49f941b12a84842dda74", null ],
    [ "name", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#a7b27ba986515997428db8e16bc957bac", null ],
    [ "posX", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#ab99d8ad059c4f623b305b93fc201ad05", null ],
    [ "posY", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#aa8adcc9f7c2420aac2e113847ad81ed8", null ],
    [ "speed", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_state_data.html#aebd6c5f446f1421d664dcdb081f4eda1", null ]
];