var class_unity_properties_1_1_unity_engine_1_1_sprite_renderer =
[
    [ "color", "class_unity_properties_1_1_unity_engine_1_1_sprite_renderer.html#ad2d3a9bb50133846f968adec99ce76bf", null ],
    [ "flipX", "class_unity_properties_1_1_unity_engine_1_1_sprite_renderer.html#aea64a31f55436d16f490d0b12da0dfb6", null ],
    [ "flipY", "class_unity_properties_1_1_unity_engine_1_1_sprite_renderer.html#ae300d3d8faae4ead109ca2780ddaa14e", null ],
    [ "pixelsPerUnit", "class_unity_properties_1_1_unity_engine_1_1_sprite_renderer.html#ab0ddb3a38e6f917d3e9dba775400abbf", null ],
    [ "sortingLayerID", "class_unity_properties_1_1_unity_engine_1_1_sprite_renderer.html#aae19f2b7e936b89982b63c7b2681d4e0", null ]
];