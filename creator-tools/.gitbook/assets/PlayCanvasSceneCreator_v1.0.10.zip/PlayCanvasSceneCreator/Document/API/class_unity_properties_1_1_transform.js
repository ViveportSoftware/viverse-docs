var class_unity_properties_1_1_transform =
[
    [ "name", "class_unity_properties_1_1_transform.html#a4710cba1181fcabe1977960c909ab460", null ],
    [ "parent", "class_unity_properties_1_1_transform.html#a588343dfc477c2893bca17e11dd9d4d9", null ]
];