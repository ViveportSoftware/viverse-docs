var class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module =
[
    [ "loop", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#aa5c2e554f4219caed0bb66dc66429625", null ],
    [ "maxParticles", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#a57fd4c91868796aa25bb06421c0de192", null ],
    [ "playOnAwake", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#afd14fac1f7f0063596f46f440b31b240", null ],
    [ "prewarm", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#ad8e592c667464f120532523724643b96", null ],
    [ "simulationSpace", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#ac42b3a777c256c01b4895686e52b44d8", null ],
    [ "startColor", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#a54faca1485c64eb9368fb612e50fc126", null ],
    [ "startLifetimeMultiplier", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#aa07925b319250d2edbee9f3f43726a03", null ],
    [ "startRotation", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#a324e59e2db55288baf8ea7ebc49ee229", null ],
    [ "startSize", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#af1a0174ba7a53c2b10c75da22eec69aa", null ],
    [ "startSpeed", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_main_module.html#a99b018735e3ad45086ae1e65f707f5f9", null ]
];