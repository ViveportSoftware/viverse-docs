var class_playcanvas_1_1_properties_1_1_texture_data =
[
    [ "Frame", "class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame.html", "class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame" ],
    [ "frames", "class_playcanvas_1_1_properties_1_1_texture_data.html#a5e8e8d85303eabd488de0285991bcfc5", null ]
];