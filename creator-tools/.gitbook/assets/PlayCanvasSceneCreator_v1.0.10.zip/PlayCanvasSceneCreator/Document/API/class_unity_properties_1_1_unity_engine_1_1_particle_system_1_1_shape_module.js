var class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_shape_module =
[
    [ "radius", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_shape_module.html#aeddb51b5027475ac8029d8395474a653", null ],
    [ "radiusThickness", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_shape_module.html#a1f52b4f675931df885c26b3414556e2e", null ],
    [ "scale", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_shape_module.html#afa4ba2ba0ea563e2fa05bc7c7b73cd93", null ],
    [ "shapeType", "class_unity_properties_1_1_unity_engine_1_1_particle_system_1_1_shape_module.html#a4200ecec1ca4410d8229fea51084141a", null ]
];