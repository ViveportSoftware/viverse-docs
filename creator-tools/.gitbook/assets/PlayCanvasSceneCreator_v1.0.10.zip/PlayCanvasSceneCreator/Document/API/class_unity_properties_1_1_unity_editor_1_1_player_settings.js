var class_unity_properties_1_1_unity_editor_1_1_player_settings =
[
    [ "defaultScreenHeight", "class_unity_properties_1_1_unity_editor_1_1_player_settings.html#ac97aeef31fbef025a7eb8bca9d463751", null ],
    [ "defaultScreenWidth", "class_unity_properties_1_1_unity_editor_1_1_player_settings.html#ac7991feeb824dc964583c904d67b6065", null ],
    [ "fullScreenMode", "class_unity_properties_1_1_unity_editor_1_1_player_settings.html#a3a0b686444f1a53cb1d5f9760bde8903", null ]
];