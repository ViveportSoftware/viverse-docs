var class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_controller_layer =
[
    [ "blendingMode", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_controller_layer.html#ac740e903bdaa465c5e2bedecfdb716c9", null ],
    [ "name", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_controller_layer.html#abeecade972a84d251dab04485e7e3970", null ],
    [ "stateMachine", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_controller_layer.html#ac91e92ab8aefdd8b8f481ad8c931140f", null ]
];