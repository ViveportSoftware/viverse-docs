var class_playcanvas_1_1_properties_1_1_sprite_data =
[
    [ "frameKeys", "class_playcanvas_1_1_properties_1_1_sprite_data.html#a40a9bdf1d43aa6a5e562b2b662b8575b", null ],
    [ "pixelsPerUnit", "class_playcanvas_1_1_properties_1_1_sprite_data.html#aec14ba493c49e6460aa7df89f58f246d", null ],
    [ "renderMode", "class_playcanvas_1_1_properties_1_1_sprite_data.html#a3416c39615a0fbb8f1f0f1f21f1f62ce", null ],
    [ "textureAtlasAsset", "class_playcanvas_1_1_properties_1_1_sprite_data.html#aa17e22f8fe12eb64b22aa344124f89f2", null ]
];