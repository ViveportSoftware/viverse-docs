var class_playcanvas_1_1_properties_1_1_sound_1_1_slot =
[
    [ "asset", "class_playcanvas_1_1_properties_1_1_sound_1_1_slot.html#a5762d533b8b48aa69df7c7c86797fdbf", null ],
    [ "autoPlay", "class_playcanvas_1_1_properties_1_1_sound_1_1_slot.html#aa8b31d97d4a2ee6a9939f38edf2ea61e", null ],
    [ "loop", "class_playcanvas_1_1_properties_1_1_sound_1_1_slot.html#ae778c5fe4c55a1704c79217091e18f36", null ],
    [ "name", "class_playcanvas_1_1_properties_1_1_sound_1_1_slot.html#a21f0be73dcd5b5d99a6b8226347f784d", null ]
];