var class_unity_properties_1_1_unity_engine_1_1_material =
[
    [ "_BumpMap", "class_unity_properties_1_1_unity_engine_1_1_material.html#a8f4319c8b4bbf4da1e3b20984f6d081a", null ],
    [ "_EmissionColor", "class_unity_properties_1_1_unity_engine_1_1_material.html#a851d2ffaf8e37a0881750d54c0909897", null ],
    [ "_EmissionMap", "class_unity_properties_1_1_unity_engine_1_1_material.html#aebf40128391f61f47f6a971a78564967", null ],
    [ "_MetallicGlossMap", "class_unity_properties_1_1_unity_engine_1_1_material.html#aeab033aa3173753240ff2a56ad12b150", null ],
    [ "_OcclusionMap", "class_unity_properties_1_1_unity_engine_1_1_material.html#a190cbac39d0edfbd20957146699edec2", null ],
    [ "_OcclusionStrength", "class_unity_properties_1_1_unity_engine_1_1_material.html#ade8b0c18b0380cae03c484ab45199537", null ],
    [ "_ParallaxMap", "class_unity_properties_1_1_unity_engine_1_1_material.html#a74ecd6c8af9c64fc29b7944b0457c4ff", null ],
    [ "color", "class_unity_properties_1_1_unity_engine_1_1_material.html#a49fa204160ec17b7bc8d68da74ebc045", null ],
    [ "mainTexture", "class_unity_properties_1_1_unity_engine_1_1_material.html#ab3233a6412abd19c437f4cdde4661699", null ],
    [ "mainTextureOffset", "class_unity_properties_1_1_unity_engine_1_1_material.html#a944f4d3e8c2f8e7da093d79c0b85f331", null ],
    [ "mainTextureScale", "class_unity_properties_1_1_unity_engine_1_1_material.html#aa8f904609180e7451d2cd2cff2db662b", null ]
];