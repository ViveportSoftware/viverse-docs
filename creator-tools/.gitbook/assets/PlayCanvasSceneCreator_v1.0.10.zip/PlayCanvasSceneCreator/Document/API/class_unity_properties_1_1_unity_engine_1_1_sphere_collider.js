var class_unity_properties_1_1_unity_engine_1_1_sphere_collider =
[
    [ "center", "class_unity_properties_1_1_unity_engine_1_1_sphere_collider.html#a211cb8e268791b226c37966488004009", null ],
    [ "enabled", "class_unity_properties_1_1_unity_engine_1_1_sphere_collider.html#a7f21d164a55a6b7b8a7fed54988e972c", null ],
    [ "radius", "class_unity_properties_1_1_unity_engine_1_1_sphere_collider.html#ae90b3974272db0898fa42f6b73cef519", null ]
];