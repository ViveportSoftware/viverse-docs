var class_playcanvas_1_1_properties_1_1_entity =
[
    [ "name", "class_playcanvas_1_1_properties_1_1_entity.html#a9e87b0fb902fbe3b0955e306974318eb", null ],
    [ "parent", "class_playcanvas_1_1_properties_1_1_entity.html#a66e7a77a715a2c30d3b5ca74be109425", null ],
    [ "tags", "class_playcanvas_1_1_properties_1_1_entity.html#a17ff28f73f0c48ee8594465787ab1c65", null ]
];