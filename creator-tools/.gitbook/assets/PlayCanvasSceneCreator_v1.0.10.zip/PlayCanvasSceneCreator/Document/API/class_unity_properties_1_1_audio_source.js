var class_unity_properties_1_1_audio_source =
[
    [ "rolloffMode", "class_unity_properties_1_1_audio_source.html#af6267aff48bc1b9d2021b2837309648d", null ]
];