var class_playcanvas_1_1_properties_1_1_rigidbody =
[
    [ "angularDamping", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a7587b66d97737c409f074ea32670fcf6", null ],
    [ "angularFactor", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a70ca83c3ff1ddd6861f09d3a5b4a6989", null ],
    [ "enabled", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a418004d7e772c9058e97c62ac562b704", null ],
    [ "friction", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a97fbcfa9bb17638ab7c51a42bad227f9", null ],
    [ "linearDamping", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a6a1cc40a8c1440fa4622bb8be1a0b426", null ],
    [ "linearFactor", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a265a32490e891a0c3506ecc2064bdd1f", null ],
    [ "mass", "class_playcanvas_1_1_properties_1_1_rigidbody.html#aeaffab6ecf3c246a3c9ec82e1a7537e9", null ],
    [ "restitution", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a0cd27baae572d344c17a31032b108eca", null ],
    [ "type", "class_playcanvas_1_1_properties_1_1_rigidbody.html#a6f2a7af16a0749281e6554491227493b", null ]
];