var class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_grid_layout_group =
[
    [ "childAlignment", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_grid_layout_group.html#a6a075427fb1180ee096ce41e88868a94", null ],
    [ "padding", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_grid_layout_group.html#aa330cabe834344e4eb28a724573f552e", null ],
    [ "spacing", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_grid_layout_group.html#a504caca27956d537fd369c723444abb6", null ],
    [ "startAxis", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_grid_layout_group.html#a52c519f770556d4c9a289bb791804e1d", null ],
    [ "startCorner", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_grid_layout_group.html#af8426def12d2e95607b527478455cf2c", null ]
];