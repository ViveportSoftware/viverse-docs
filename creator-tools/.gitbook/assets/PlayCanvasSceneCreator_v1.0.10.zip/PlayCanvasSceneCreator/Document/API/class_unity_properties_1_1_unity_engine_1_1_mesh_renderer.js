var class_unity_properties_1_1_unity_engine_1_1_mesh_renderer =
[
    [ "receiveShadows", "class_unity_properties_1_1_unity_engine_1_1_mesh_renderer.html#a3ac1c92aa01f654553ba736ad1a3aec6", null ],
    [ "shadowCastingMode", "class_unity_properties_1_1_unity_engine_1_1_mesh_renderer.html#a7b5b3e5d42be8ec8fbfea0b68cb86acd", null ],
    [ "sharedMaterials", "class_unity_properties_1_1_unity_engine_1_1_mesh_renderer.html#a89737b1a2c56df54d3e773078e4bf72d", null ]
];