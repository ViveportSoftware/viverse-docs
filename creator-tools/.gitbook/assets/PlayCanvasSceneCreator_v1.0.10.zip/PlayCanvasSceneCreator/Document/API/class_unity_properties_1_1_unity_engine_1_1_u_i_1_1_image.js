var class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image =
[
    [ "Type", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#af800b2c90c7165dd8689d38c39b254d1", [
      [ "Simple", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#af800b2c90c7165dd8689d38c39b254d1a1fbb1e3943c2c6c560247ac8f9289780", null ],
      [ "Sliced", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#af800b2c90c7165dd8689d38c39b254d1afa6a7b9fa989f179f6bbf2796bf4337c", null ],
      [ "Tiled", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#af800b2c90c7165dd8689d38c39b254d1a320af35370596a9ea75686c6624a9f07", null ],
      [ "Filled", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#af800b2c90c7165dd8689d38c39b254d1ad9d586f8c792f8f661052af42536323c", null ]
    ] ],
    [ "color", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#aeebfa8fccdb4cef9070a7249cd363706", null ],
    [ "sprite", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#a6663133c78b561bdb8c1f44765f30d95", null ],
    [ "type", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_image.html#a8768493d452159fa07adc610769b44da", null ]
];