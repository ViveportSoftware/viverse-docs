var class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_button_1_1colors =
[
    [ "disabledColor", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_button_1_1colors.html#a2d82bb370e2d08343ab1cada39c25efd", null ],
    [ "highlightedColor", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_button_1_1colors.html#a0d5d292cc1fad8282dacce3ad6f6d92f", null ],
    [ "pressedColor", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_button_1_1colors.html#a941dbf5879a670bd45e454647a67f3a0", null ]
];