var class_unity_properties_1_1_unity_engine_1_1_physic_material =
[
    [ "bounciness", "class_unity_properties_1_1_unity_engine_1_1_physic_material.html#ac4739ee777f2e727d01253864f31f4bb", null ],
    [ "dynamicFriction", "class_unity_properties_1_1_unity_engine_1_1_physic_material.html#a516041238c0604167d2b2d4bea881787", null ]
];