var class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_state_transition =
[
    [ "destinationState", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_state_transition.html#a8bfa50e9e3c2739c0feae0dbccda31eb", null ],
    [ "exitTime", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_state_transition.html#ae37d52bd8be93ab1d4701dee8dbaa587", null ],
    [ "interruptionSource", "class_unity_properties_1_1_unity_editor_1_1_animations_1_1_animator_state_transition.html#ada6b523593214db62cba5dff07fd3ef4", null ]
];