var class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text =
[
    [ "alignment", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#a64af7a2a083278ab7d54ae3c01766e61", null ],
    [ "color", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#acb2f39fe8fe142255334a7d6e8b61f3d", null ],
    [ "font", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#ab75138ee66bc671575243b28a2e3970c", null ],
    [ "fontSize", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#ac97b1df5b28813e6948de6c778fab8bd", null ],
    [ "resizeTextMaxSize", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#ad513d5a600aedbcbbd5e75ff4fdd8c21", null ],
    [ "resizeTextMinSize", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#a9a320af444a602cca9bb95299524cef2", null ],
    [ "text", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_text.html#a14e1db1c20ebb82ce94d4d48f25cb447", null ]
];