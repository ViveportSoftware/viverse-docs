var class_unity_properties_1_1_unity_engine_1_1_quality_settings =
[
    [ "antiAliasing", "class_unity_properties_1_1_unity_engine_1_1_quality_settings.html#a25476ca8ebb0b7d1f550f81da0a16874", null ]
];