var class_unity_properties_1_1_unity_engine_1_1_sprite =
[
    [ "border", "class_unity_properties_1_1_unity_engine_1_1_sprite.html#a630284a610cece466b73c7cc4d891746", null ],
    [ "bounds", "class_unity_properties_1_1_unity_engine_1_1_sprite.html#a76f6741776652e28522def6cc71cd70d", null ],
    [ "name", "class_unity_properties_1_1_unity_engine_1_1_sprite.html#a3a4d2ed4df5b77602a71ffa400777449", null ],
    [ "rect", "class_unity_properties_1_1_unity_engine_1_1_sprite.html#abd1ab14c9d39dd6c31ed32104d591511", null ]
];