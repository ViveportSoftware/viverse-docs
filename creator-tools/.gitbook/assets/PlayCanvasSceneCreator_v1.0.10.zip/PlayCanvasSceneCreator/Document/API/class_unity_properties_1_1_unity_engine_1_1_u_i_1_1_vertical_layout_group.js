var class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group =
[
    [ "childAlignment", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#a9ee4826ed21d84d9a38f943b43e662bb", null ],
    [ "childControlHeight", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#a2487dcb2478126b3b9ed3ef0507f680b", null ],
    [ "childControlWidth", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#aba754485151a0d825b76c5a3e990ba82", null ],
    [ "enable", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#a0c8b5c2c52f6e40ac04256ff260bf1c3", null ],
    [ "padding", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#a2295f014ebfd175da6ede8de1504dfbd", null ],
    [ "reverseArrangement", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#a77821605029a7764acc33ebe57207e1c", null ],
    [ "spacing", "class_unity_properties_1_1_unity_engine_1_1_u_i_1_1_vertical_layout_group.html#a1953700d198cf56e22fab89a30f1e530", null ]
];