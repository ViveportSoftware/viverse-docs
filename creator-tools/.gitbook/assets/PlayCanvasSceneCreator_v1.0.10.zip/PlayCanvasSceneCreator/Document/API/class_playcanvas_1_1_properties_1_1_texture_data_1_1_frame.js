var class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame =
[
    [ "border", "class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame.html#a2d16e7d8f41e63dd776ad945d9f93c79", null ],
    [ "name", "class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame.html#a5a7a71ac93e203db8fa4390d3951319f", null ],
    [ "pivot", "class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame.html#a2096c01b31d7be9e14ff90c562d0c223", null ],
    [ "rect", "class_playcanvas_1_1_properties_1_1_texture_data_1_1_frame.html#aa677d9ee38ab622ee8c018c6d0c2927a", null ]
];