var class_unity_properties_1_1_unity_engine_1_1_particle_system_renderer =
[
    [ "alignment", "class_unity_properties_1_1_unity_engine_1_1_particle_system_renderer.html#ab196d3ce42effe2ba3d440c97054cda4", null ],
    [ "mesh", "class_unity_properties_1_1_unity_engine_1_1_particle_system_renderer.html#a5b398606226dbd77079e4f772a4dbd92", null ],
    [ "sortMode", "class_unity_properties_1_1_unity_engine_1_1_particle_system_renderer.html#a1c3ada2b5d878374da6f36d3a9fc9b99", null ]
];