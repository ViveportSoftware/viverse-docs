var class_unity_properties_1_1_unity_engine_1_1_canvas_group =
[
    [ "alpha", "class_unity_properties_1_1_unity_engine_1_1_canvas_group.html#a0f4b77979eb68b36e61704c93baa1858", null ],
    [ "interactable", "class_unity_properties_1_1_unity_engine_1_1_canvas_group.html#ae3a7475725b1754885e896041b8bdc7c", null ]
];