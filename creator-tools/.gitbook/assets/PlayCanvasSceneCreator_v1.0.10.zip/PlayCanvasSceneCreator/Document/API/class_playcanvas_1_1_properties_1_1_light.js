var class_playcanvas_1_1_properties_1_1_light =
[
    [ "affectDynamic", "class_playcanvas_1_1_properties_1_1_light.html#ac1077d8cf25b62941ffb0fe0cece7669", null ],
    [ "castShadows", "class_playcanvas_1_1_properties_1_1_light.html#a185a483f901ea6b9d30bdceb8899b0d8", null ],
    [ "color", "class_playcanvas_1_1_properties_1_1_light.html#a032baf4bc55cc9ec04114db88c6d43c2", null ],
    [ "cookieAsset", "class_playcanvas_1_1_properties_1_1_light.html#a4c4ec5d7bb53f6c0eb1d28723da89abc", null ],
    [ "innerConeAngle", "class_playcanvas_1_1_properties_1_1_light.html#a0d008d092a8c9a2b7732bf3874d18db1", null ],
    [ "intensity", "class_playcanvas_1_1_properties_1_1_light.html#a5379444015bec308357e493ced34f443", null ],
    [ "isStatic", "class_playcanvas_1_1_properties_1_1_light.html#a4a518d262cbd7fc766f35b4f30a4251a", null ],
    [ "layers", "class_playcanvas_1_1_properties_1_1_light.html#a182b850be4a53e5d5512e71b1bddf2e0", null ],
    [ "outerConeAngle", "class_playcanvas_1_1_properties_1_1_light.html#a9792a968e54c2f3195901eefbf3d7c5f", null ],
    [ "range", "class_playcanvas_1_1_properties_1_1_light.html#a501271b26473280118a8b7b569bbcb1c", null ],
    [ "shadowResolution", "class_playcanvas_1_1_properties_1_1_light.html#aa685195a72bb9036db9751150977da5a", null ],
    [ "type", "class_playcanvas_1_1_properties_1_1_light.html#adbdea8b80b9a168c64f298142b034440", null ]
];