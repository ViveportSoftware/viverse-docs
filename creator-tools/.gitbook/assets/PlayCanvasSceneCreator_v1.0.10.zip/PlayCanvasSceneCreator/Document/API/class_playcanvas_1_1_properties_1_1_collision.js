var class_playcanvas_1_1_properties_1_1_collision =
[
    [ "Type", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707", [
      [ "mesh", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707a09bc81c3aa886b690f84c5aba4109e20", null ],
      [ "box", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707a34be958a921e43d813a2075297d8e862", null ],
      [ "capsule", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707a2716373f1a0b85c7d8fb074fb4fc61c7", null ],
      [ "sphere", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707a34248a9bfcbd589d9b5fccb6a0ac6963", null ],
      [ "cylinder", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707a9c7cd9fc9aa15fae1e37885314637c36", null ],
      [ "cone", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707a29d6fc960c94b5a330f850284e75ab1f", null ],
      [ "compound", "class_playcanvas_1_1_properties_1_1_collision.html#a6647b4295a9864c59006b232436f2707ab9937ba090537685b0a0f1d6a11fd31e", null ]
    ] ],
    [ "axis", "class_playcanvas_1_1_properties_1_1_collision.html#ab30bf735e1d68ab1cb02acb0a7caf47e", null ],
    [ "enabled", "class_playcanvas_1_1_properties_1_1_collision.html#a13e5575b77c2d9a4a426200e1de1a408", null ],
    [ "halfExtents", "class_playcanvas_1_1_properties_1_1_collision.html#a497a8dfe0b21909ce1c179122b50c9a0", null ],
    [ "height", "class_playcanvas_1_1_properties_1_1_collision.html#a22448c4e0d58ad9f04c03bd132bd1d6c", null ],
    [ "linearOffset", "class_playcanvas_1_1_properties_1_1_collision.html#afc4539dc497efadb334c0e34faf147a9", null ],
    [ "radius", "class_playcanvas_1_1_properties_1_1_collision.html#a8d4b41d9b2ed498e7942fd3e6cd46490", null ]
];