var class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_transition_data_1_1_condition =
[
    [ "parameterName", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_transition_data_1_1_condition.html#a7049a6c0d8bd88cad6fb0c536ae1c7eb", null ],
    [ "predicate", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_transition_data_1_1_condition.html#a1ddf801dc00f8f6a149fcc4e09223112", null ],
    [ "value", "class_playcanvas_1_1_properties_1_1_animation_state_data_1_1_transition_data_1_1_condition.html#aeb8f2511bfbf6c51e65277d0d02bcd3f", null ]
];